[![Python 3.5](https://img.shields.io/badge/Python-3.5-yellow.svg)](http://www.python.org/download/)
[![python](https://img.shields.io/badge/python-2.7-brightgreen.svg)](https://www.python.org/downloads/release/python-2714/)
[![OS](https://img.shields.io/badge/Tested%20On-Linux%20%7C%20Android-yellowgreen.svg)](https://termux.com/)






# Wifi-Hacking.py  ![alt tag](http://icons.iconarchive.com/icons/icons8/ios7/48/Network-Wifi-Logo-icon.png)



No Need To Ask Wifi Password, HACK it..! This Cyber Security Tool, Will Hack For You Any Wifi-Password..!


[![asciicast](https://asciinema.org/a/362908.svg)](https://asciinema.org/a/362908)


## Feutures and Contains :


```bash 
1)Start monitor mode

2)Stop monitor mode

3)Scan Networks   

4)Getting Handshake

5)Create wordlist

6)Install Wireless tools                  

7)WPS Networks attacks 

8)Scan for WPS Networks

9)Crack Handshake with rockyou.txt

10)Crack Handshake with wordlist

11)Crack Handshake without wordlist
```

## Tested On :

* Kali Linux
* BlackArch Linux
* Ubuntu
* Kali Nethunter
* Termux ( Rooted Devices)
* Parrot OS


# Installation


### Kali Linux / Ubuntu / Parrot OS

```bash
1) sudo apt-get update && apt-get install git
2) sudo git clone https://github.com/ankit0183/Wifi-Hacking
3) cd Wifi-Hacking/
4) sudo python3 Wifi-Hacking.py
```

## Creator

(Ankit Kanojiya) Hey, Dont Forget To say Thanks me :smile:


# SCREENSHOT


![](Snapshots/0.png)
![](Snapshots/1.png)
![](Snapshots/2.png)
![](Snapshots/3.png)
![](Snapshots/4.png)
![](Snapshots/5.png)
![](Snapshots/6.png)
![](Snapshots/7.png)





# Feel Free To Contact Me.


 ### if you like my work, Buy me a Cup of Coffee PhonePay/PayTm/GPAy 9768367597

### - [Whats App chat](https://wa.me/+919768367597)

### - [Instagram](https://www.instagram.com/ankit_kanojiiya/)


# Disclaimer 


Wifi-Hacking tool not responsible for misuse and for illegal purposes. Use it only for Pentest or Educational purpose :smile: !!!



> Pull requests are always welcome.. :)  





###### Donation

If this CyberSecurity tool has been useful for you, feel free to thank me by buying me a coffee. :)
 
 
 
 
### Happy Hacking ( Privacy & Security No Such Things Exists in digital World, We Can Hack Everything )





